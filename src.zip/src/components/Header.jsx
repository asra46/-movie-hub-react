import React from 'react'
import "./component.css"
import ToggleSwitch from './ToggleSwitch';

const Header = ({ setCategory }) => {
  return (
    <div className="navbar">
      <h1 className="logo">Movie Hub</h1>

      <ul className="navbar-items">
        <li className='nav-item'><ToggleSwitch/></li>
        <li className='nav-item' onClick={() => setCategory("popular")}>Popular 🔥</li>
        <li className='nav-item' onClick={() => setCategory("top_rated")}>Top Rated ⭐</li>
        <li className='nav-item' onClick={() => setCategory("upcoming")}>Upcoming 🎬</li>
      </ul>
    </div>
  );
};

export default Header;

